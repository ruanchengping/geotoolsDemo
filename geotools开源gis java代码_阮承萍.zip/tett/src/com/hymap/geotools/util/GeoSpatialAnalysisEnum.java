package com.hymap.geotools.util;
/**
 * 
* @ClassName: GeoSpatialAnalysisEnum 
* @Description: TODO(空间分析关系枚举类型) 
* @author ruanchengping 
* @date 2016-9-2 上午10:16:21 
*
 */
public class GeoSpatialAnalysisEnum {
	
	public static enum spatial {
		intersect, contains, within, cross, overlaps, touches, equals, disjoint
	}

}
